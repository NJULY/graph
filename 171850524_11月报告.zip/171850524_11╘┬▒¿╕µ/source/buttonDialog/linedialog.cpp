#include "lineDialog.h"
#include "ui_linedialog.h"

lineDialog::lineDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::lineDialog)
{
    ui->setupUi(this);
    setWindowTitle(tr("直线信息"));
    x1 = 0; x2 = 0; y1 = 0; y2 = 0;
    color = QColor(0,0,0);
}

lineDialog::~lineDialog()
{
    delete ui;
}

void lineDialog::getVal(int& x1, int& y1, int& x2, int& y2, QColor& color)
{
    x1 = this->x1;
    x2 = this->x2;
    y1 = this->y1;
    y2 = this->y2;
    color = this->color;
}

void lineDialog::on_colorButton_clicked()
{
    QColorDialog* colorDialog = new QColorDialog();
    color = colorDialog->getColor();
    QString colorStr=QString("background-color:rgb(%1,%2,%3);").arg(color.red()).arg(color.green()).arg(color.blue());
    ui->colorLineEdit->setStyleSheet(colorStr);
    delete colorDialog;
}

void lineDialog::on_okButton_clicked()
{
    x1 = ui->x1Val->value();
    x2 = ui->x2Val->value();
    y1 = ui->y1Val->value();
    y2 = ui->y2Val->value();
    close();
}

void lineDialog::on_cancleButton_clicked()
{
    close();
}
