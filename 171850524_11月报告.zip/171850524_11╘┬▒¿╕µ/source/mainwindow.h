#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPainter>
#include <QPixmap>
#include <QDialog>
#include <QVector>
#include <QString>
#include <QStack>
#include <QColor>
#include <QColorDialog>
#include <QFileDialog>
#include <QMessageBox>
#include <QMouseEvent>
#include "graphUnit/graphUnit.h"
#include "graphUnit/line.h"
#include "graphUnit/circle.h"
#include "graphUnit/ellipse.h"
#include "graphUnit/rectangle.h"
#include "buttonDialog/lineDialog.h"
#include "buttonDialog/resetCanvasDialog.h"
#include "controller.h"
#include "transformation.h"
#include "dyer.h"

enum mouseCommand {mouseFree,mouseDraw, mouseDye,
                   mouseTranslate, mouseRotateBegin, mouseRotateIng,
                   mouseScaleBegin, mouseScaleIng,
                   mouseClip
                  };
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
protected:
    void paintEvent(QPaintEvent *event);//重写绘图函数
    void mousePressEvent(QMouseEvent *event);//处理鼠标按下
    void mouseMoveEvent(QMouseEvent *event);//处理鼠标移动
    void mouseReleaseEvent(QMouseEvent *event);//处理鼠标松开
private slots:
    void on_Line_clicked();//画线
    void on_openButton_clicked();//打开画布
    void on_saveButton_clicked();//保存画布
    void on_resetButton_clicked();//重置画布
    void on_colorButton_clicked();//选择颜色
    void on_cmdLineButton_clicked();//废弃
    void on_undoButton_clicked();//撤销 还未实现
    void on_cmdCircleButton_clicked();//鼠标画圆
    void on_cmdEllipseButton_clicked();//鼠标画椭圆
    void on_cmdPolygonButton_clicked();//鼠标画多边形
    void on_dyeButton_clicked();

    void on_cmdTranslateButton_clicked();

    void on_cmdRotateButton_clicked();

    void on_cmdScaleButton_clicked();

    void on_cmdClipButton_clicked();

private:
    Ui::MainWindow *ui;
    //自定义所需变量
    QPixmap* canvas;//画布
    graphUnit* unit;
    QColor color;//主界面选择的颜色
    mouseCommand mCmd;//鼠标命令
    Controller controller;//图元控制
    Dyer dyer;
    QPoint startPoint;
    QPoint endPoint;
    QPoint rotatePoint;//旋转基准点
    QPoint scalePoint;//缩放基准点

    QString path;
    int canvasW;
    int canvasH;
    void resetCanvas(int w, int h);
};

#endif // MAINWINDOW_H
