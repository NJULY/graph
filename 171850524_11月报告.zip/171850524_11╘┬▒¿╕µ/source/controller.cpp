#include "controller.h"


Controller::Controller()
{
    unit = nullptr;
    cmd = cmdFree;
    lineAlgorithm = 0;
    clipAlgorithm = 0;
}

void Controller::addGraph(QPoint startPoint, QPoint endPoint, QColor color, int lineSize)
{
    if(cmd == cmdDrawLine)//画直线，鼠标开始和结束分别对应着直线端点
    {
        int x1, y1, x2, y2;
        x1 = startPoint.x();
        y1 = startPoint.y();
        x2 = endPoint.x();
        y2 = endPoint.y();
        //printf("%d-%d-%d-%d ",x1,y1,x2,y2);
        unit = new Line(x1, y1, x2, y2, color, lineSize);
        graphs.push_back(unit);
    }
    else if(cmd == cmdDrawCircle)//画圆，鼠标点击为圆心，移动中计算半径
    {
        int x, y, r;
        int rX, rY;
        x = startPoint.x();
        y = startPoint.y();
        rX = endPoint.x();
        rY = endPoint.y();
        r = (int)sqrt(abs(rX - x)*abs(rX - x)+abs(rY - y)*abs(rY - y));
        unit = new Circle(x, y, r, color, lineSize);
        graphs.push_back(unit);
    }
    else if(cmd == cmdDrawEllipse)//画椭圆，鼠标起点为椭圆中心，终点与起点可计算两个轴
    {
        int x, y, rx, ry;
        int sx, sy, ex, ey;
        sx = startPoint.x();
        sy = startPoint.y();
        ex = endPoint.x();
        ey = endPoint.y();
        x = sx;
        y = sy;
        rx = abs(sx-ex);
        ry = abs(sy-ey);
        unit = new Ellipse(x, y, rx, ry, color, lineSize);
        graphs.push_back(unit);
    }
    else if(cmd == cmdDrawPolygonStart){
        int x1, y1, x2, y2;
        x1 = startPoint.x();
        y1 = startPoint.y();
        x2 = endPoint.x();
        y2 = endPoint.y();
        Line* line = new Line(x1, y1, x2, y2, color, lineSize);
        Polygon* polygon = new Polygon(color, lineSize);
        polygon->pushLine(*line);
        delete line;
        unit = polygon;
        graphs.push_back(unit);
    }
    else if(cmd == cmdDrawPolygonIng)
    {
        int x1, y1, x2, y2;
        x1 = startPoint.x();
        y1 = startPoint.y();
        x2 = endPoint.x();
        y2 = endPoint.y();
        Line* line = new Line(x1, y1, x2, y2, color, lineSize);
        int size = graphs.size();
        if(graphs[size-1]->getShape() == shapePolygon)
        {
            Polygon* polygon = (Polygon*)graphs[size-1];
            polygon->pushLine(*line);
            delete line;
        }
        else
        {
            printf("栈顶元素非多边形!\n");
        }
    }
}

void Controller::removeGraph()
{
    if(graphs.isEmpty() == false)
    {
        if(cmd == cmdDrawPolygonIng)
        {
            int size = graphs.size();
            if(graphs[size-1]->getShape() == shapePolygon)
            {
                Polygon* polygon = (Polygon*)graphs[size-1];
                polygon->popLine();
            }
            else
            {
                printf("栈顶元素非多边形!\n");
            }
        }
        else
        {
            unit = graphs[graphs.size()-1];
            delete unit;
            graphs.pop_back();
        }
    }
}

void Controller::reset()
{
    graphs.clear();
}

void Controller::paint(QPixmap* canvas)
{
    QVector<graphUnit*>::iterator i;
    for(i = graphs.begin(); i != graphs.end(); i++)
    {
        unit = *i;
        if(unit->getShape() == shapeLine)
        {
            Line* line = (Line*)unit;
            if(line != nullptr)
            {
                if(line->clipOut == false)
                {
                    if(lineAlgorithm == 1)
                        line->Bresenham_paint(canvas);
                    else
                        line->DDA_paint(canvas);
                }
            }
        }
        else if(unit->getShape() == shapeCircle)
        {
            Circle* circle = (Circle*)unit;
            if(circle != nullptr)
            {
                circle->paint(canvas);
            }
        }
        else if(unit->getShape() == shapeEllipse)
        {
            Ellipse* ellipse = (Ellipse*)unit;
            if(ellipse != nullptr)
            {
                ellipse->paint(canvas);
            }
        }
        else if(unit->getShape() == shapePolygon)
        {
            Polygon* polygon = (Polygon*)unit;
            if(polygon != nullptr)
            {
                polygon->paint(canvas);
            }
        }
        else if(unit->shape == shapeRectangle)
        {
            Rectangle* rectangle = (Rectangle*)unit;
            if(rectangle != nullptr)
            {
                rectangle->paint(canvas);
            }
        }
        if(unit->beDyed == true)
            dyer.dyeGraph(unit,canvas);
    }
}

void Controller::choseGraph(graphUnit *unit, int x, int y)
{
    Shape shape = unit->shape;
    if(shape == shapeLine)
    {
        Line* line = (Line*)unit;
        if(x < (line->x1 < line->x2 ? line->x1 : line->x2))
            return;
        if(x > (line->x1 < line->x2 ? line->x2 : line->x1))
            return;
        if(y < (line->y1 < line->y2 ? line->y1 : line->y2))
            return;
        if(y > (line->y1 < line->y2 ? line->y2 : line->y1))
            return;
        if(line->x1 == line->x2)
        {
            if(abs(x - line->x1) < 5)
            {
                line->beChosen = true;
            }
            else
            {
                line->beChosen = false;
            }
            return;
        }
        else
        {   //y = (y1-y2)/(x1-x2)*(x-x1)+y1
            int y1 = (double)(line->y1-line->y2)/(double)(line->x1-line->x2)*(x-line->x1) + line->y1;
            if(abs(y-y1) < 10)
                line->beChosen = true;
            else
                line->beChosen = false;
            return;
        }
    }
    else if(shape == shapeCircle)
    {
        Circle* circle = (Circle*)unit;
        int r1 = (int)sqrt((x-circle->x)*(x-circle->x) + (y-circle->y)*(y-circle->y));
        if(abs(r1 - circle->r) < 10)
            circle->beChosen = true;
        else
            circle->beChosen = false;
    }
    else if(shape == shapeEllipse)
    {
        Ellipse* ellipse = (Ellipse*)unit;
        int a = ellipse->rx;
        int b = ellipse->ry;
        int xe = ellipse->x;
        int ye = ellipse->y;
        double d2 = (double)((x-xe)*(x-xe))/(double)(a*a) + (double)((y-ye)*(y-ye))/(b*b);
        if( d2 < 1.05 && d2 > 0.95)
        {
            ellipse->beChosen = true;
            //printf("-test ellipse success-");
        }
        else
        {
            ellipse->beChosen = false;
            //printf("-test ellipse fail a:%d,b:%d,xe:%d,ye:%d,x:%d,y:%d,delta:%d-",
                   //a,b,xe,ye,x,y,abs(d2 - a*a*b*b));
        }
    }
    else if(shape == shapePolygon)
    {
        Polygon* polygon = (Polygon*)unit;
        int len = polygon->lineVector.size();
        for(int i = 0; i< len; i++)
        {
            Line* line = &(polygon->lineVector[i]);
            choseGraph(line,x,y);
            if(line->beChosen == true)
            {
                polygon->beChosen = true;
                line->beChosen = false;
                return;
            }
        }
        polygon->beChosen = false;
    }
    else
    {

    }
}

double Controller::getAngle(int x1, int y1, int x2, int y2)
{
    if(y1 == y2 && x2 >= x1)
        return 0;
    else if(y1 == y2 && x2 < x1)
        return PI;
    else if(x1 == x2 && y2 >= y1)
        return PI*0.5;
    else if(x1 == x2 && y2 < y1)
        return PI*1.5;
    else
    {
        int deltaX = abs(x1-y1);
        int deltaY = abs(y1-y2);
        double angle = atan(deltaY/deltaX);
        if(x2 > x1 && y2 > y1)
            return angle;
        else if(x2 < x1 && y2 > y1)
            return PI - angle;
        else if(x2 < x1 && y2 < y1)
            return PI + angle;
        else
            return 2*PI - angle;
    }
}
