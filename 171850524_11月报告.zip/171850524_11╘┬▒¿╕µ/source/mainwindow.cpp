#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->resize(1000,1000);
    setWindowTitle(tr("My Board"));


    canvasW = 600;
    canvasH = 600;
    canvas = new QPixmap(canvasW,canvasH);
    canvas->fill(Qt::white);

    unit = nullptr;
    mCmd = mouseFree;
    path = "";

    color = QColor(0,180,180);
    QString colorStr=QString("background-color:rgb(%1,%2,%3);").arg(color.red()).arg(color.green()).arg(color.blue());
    ui->colorLine->setStyleSheet(colorStr);

    this->update();

    ui->lineSizeSlider->setValue(1);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *)
{
    if(path == "")
    {
        delete canvas;
        canvas = new QPixmap(canvasW,canvasH);
        canvas->fill(Qt::white);
    }
    else
    {
        canvas->load(path);
    }
    controller.paint(canvas);
    ui->imgLabel->resize(canvasW,canvasW);
    ui->imgLabel->setPixmap(*canvas);
}

void MainWindow::on_Line_clicked()//暂时废弃
{
    /*lineDialog* lineData = new lineDialog();
    lineData->exec();
    int x1, y1, x2, y2;
    QColor tmpColor;
    lineData->getVal(x1, y1, x2, y2, tmpColor);
    Ellipse* newLine = new Ellipse(x1, y1, x2, y2, tmpColor);
    delete lineData;
    controller.graphs.append(newLine);
    unit = newLine;
    controller.cmd = cmdDrawEllipse;*/
    controller.graphs.append(new Ellipse(300,300,280,300,color,200));
    this->update();
}

void MainWindow::on_resetButton_clicked()
{
    resetCanvasDialog* resetDialog = new resetCanvasDialog();
    resetDialog->exec();
    int w = 600, h = 600;
    if(resetDialog->isDataValid() == true)
    {
        w = resetDialog->getWidth();
        h = resetDialog->getHeight();
        resetCanvas(w,h);
    }
    delete resetDialog;
}
void MainWindow::resetCanvas(int w, int h)//重置画布，供button函数和文件指令调用
{
    controller.cmd = cmdFree;
    controller.reset();
    path = "";
    canvasW = w;
    canvasH = h;
    update();
}

void MainWindow::on_colorButton_clicked()//从主界面获取颜色
{
    QColorDialog* colorDialog = new QColorDialog();
    color = colorDialog->getColor();
    QString colorStr=QString("background-color:rgb(%1,%2,%3);").arg(color.red()).arg(color.green()).arg(color.blue());
    ui->colorLine->setStyleSheet(colorStr);
    delete colorDialog;
}

void MainWindow::mousePressEvent(QMouseEvent *event)//处理鼠标按下
{
    if(event->button() == Qt::LeftButton)
    {
        if(mCmd == mouseDraw)//绘制图元
        {
            if(controller.cmd == cmdDrawPolygonStart)
            {
                startPoint = event->globalPos();
                startPoint = ui->imgLabel->mapFromGlobal(startPoint);
                endPoint = event->globalPos();
                endPoint = ui->imgLabel->mapFromGlobal(endPoint);
                controller.addGraph(startPoint,endPoint,color,ui->lineSizeSlider->value());
                controller.cmd = cmdDrawPolygonIng;
            }
            else if(controller.cmd == cmdDrawPolygonIng)
            {
                endPoint = event->globalPos();
                endPoint = ui->imgLabel->mapFromGlobal(endPoint);
                controller.addGraph(startPoint,endPoint,color,ui->lineSizeSlider->value());
            }
            else
            {
                if(controller.cmd == cmdDrawLine)//画线时，需要选择画线的算法
                {
                    if(ui->line1->checkState() == Qt::Checked)
                        controller.lineAlgorithm = 0;
                    else if(ui->line2->checkState() == Qt::Checked)
                        controller.lineAlgorithm = 1;
                    else
                        controller.lineAlgorithm = 1;
                }
                startPoint = event->globalPos();
                startPoint = ui->imgLabel->mapFromGlobal(startPoint);
                endPoint = event->globalPos();
                endPoint = ui->imgLabel->mapFromGlobal(endPoint);
                controller.addGraph(startPoint,endPoint,color,ui->lineSizeSlider->value());
            }
            update();
        }
        else if(mCmd == mouseDye)
        {
            startPoint = event->globalPos();
            startPoint = ui->imgLabel->mapFromGlobal(startPoint);
            int size = controller.graphs.size();
            for(int i = 0; i < size; i++)
            {
                if(controller.dyer.inOutTest(controller.graphs[i],startPoint) == true)
                {
                    controller.graphs[i]->beDyed = true;
                    controller.graphs[i]->dyeColor = color;
                }
            }
        }
        else if(mCmd == mouseTranslate)
        {
             startPoint = event->globalPos();
             startPoint = ui->imgLabel->mapFromGlobal(startPoint);
             int x = startPoint.x();
             int y = startPoint.y();
             int len = controller.graphs.size();
             for(int i = 0; i < len; i++)
             {
                controller.choseGraph(controller.graphs[i],x,y);
                if(controller.graphs[i]->beChosen == true)
                {
                    controller.graphs[i]->lastX = x;
                    controller.graphs[i]->lastY = y;
                }
             }
        }
        else if(mCmd == mouseRotateBegin)
        {
            //Begin作用是选择旋转点
            startPoint = event->globalPos();
            startPoint = ui->imgLabel->mapFromGlobal(startPoint);
            rotatePoint = startPoint;
        }
        else if(mCmd == mouseRotateIng)
        {
            startPoint = event->globalPos();
            startPoint = ui->imgLabel->mapFromGlobal(startPoint);
            int x = startPoint.x();
            int y = startPoint.y();
            int len = controller.graphs.size();
            for(int i = 0; i < len; i++)
            {
               controller.choseGraph(controller.graphs[i],x,y);
               if(controller.graphs[i]->beChosen == true)
               {
                   Transformation::rotate(controller.graphs[i],rotatePoint.x(),rotatePoint.y(),ui->rotateBox->value()/180.0*PI);
               }
            }
        }
        else if(mCmd == mouseScaleBegin)
        {
            //Begin作用是选择缩放基准点
            startPoint = event->globalPos();
            startPoint = ui->imgLabel->mapFromGlobal(startPoint);
            scalePoint = startPoint;
        }
        else if(mCmd == mouseScaleIng)
        {
            startPoint = event->globalPos();
            startPoint = ui->imgLabel->mapFromGlobal(startPoint);
            int x = startPoint.x();
            int y = startPoint.y();
            int len = controller.graphs.size();
            for(int i = 0; i < len; i++)
            {
               controller.choseGraph(controller.graphs[i],x,y);
               if(controller.graphs[i]->beChosen == true)
               {
                   Transformation::scale(controller.graphs[i],scalePoint.x(),scalePoint.y(),ui->scaleBox->value());
               }
            }
        }
        else if(mCmd == mouseClip)
        {
            startPoint = event->globalPos();
            startPoint = ui->imgLabel->mapFromGlobal(startPoint);
            endPoint = startPoint;
            Rectangle* rectangle = new Rectangle(startPoint.x(),startPoint.y(),endPoint.x(),endPoint.y(),
                                                 color, ui->lineSizeSlider->value());
            controller.graphs.push_back(rectangle);
        }
    }
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)//处理鼠标移动
{
    if(mCmd == mouseDraw)
    {
        endPoint = event->globalPos();
        endPoint = ui->imgLabel->mapFromGlobal(endPoint);
        controller.removeGraph();
        controller.addGraph(startPoint,endPoint,color,ui->lineSizeSlider->value());
        update();
    }
    else if(mCmd == mouseTranslate)
    {
        endPoint = event->globalPos();
        endPoint = ui->imgLabel->mapFromGlobal(endPoint);
        int x = endPoint.x();
        int y = endPoint.y();
        int len = controller.graphs.size();
        for(int i = 0; i < len; i++)
        {
            if(controller.graphs[i]->beChosen == true)
            {
                int lastX = controller.graphs[i]->lastX;
                int lastY = controller.graphs[i]->lastY;
                Transformation::translate(controller.graphs[i],x-lastX,y-lastY);
                controller.graphs[i]->lastX = x;
                controller.graphs[i]->lastY = y;
            }
        }
    }
    else if(mCmd == mouseClip)
    {
        endPoint = event->globalPos();
        endPoint = ui->imgLabel->mapFromGlobal(endPoint);
        int size = controller.graphs.size();
        Rectangle* rectangle = (Rectangle*)controller.graphs[size - 1];
        rectangle->x2 = endPoint.x();
        rectangle->y2 = endPoint.y();
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)//处理鼠标松开
{
    if(event->button() == Qt::LeftButton)
    {
        if(mCmd == mouseDraw)
        {
            if(controller.cmd == cmdDrawPolygonIng)
            {
                endPoint = event->globalPos();
                endPoint = ui->imgLabel->mapFromGlobal(endPoint);
                int size = controller.graphs.size();
                if(controller.graphs[size-1]->getShape() == shapePolygon)
                {
                    Polygon* polygon = (Polygon*)controller.graphs[size-1];
                    QPoint s = polygon->getStart();
                    int x1 = s.x(), y1 = s.y();
                    int x2 = endPoint.x(), y2 = endPoint.y();
                    if(abs(x1-x2)<=20 && abs(y1-y2)<=20)
                    {
                        controller.removeGraph();
                        controller.addGraph(startPoint,s,color,ui->lineSizeSlider->value());
                        controller.cmd = cmdDrawPolygonStart;
                    }
                    else
                    {
                        controller.removeGraph();
                        controller.addGraph(startPoint,endPoint,color,ui->lineSizeSlider->value());
                        controller.cmd = cmdDrawPolygonIng;
                        startPoint = endPoint;
                    }
                }
                else
                {
                    printf("栈顶元素非多边形!in function mouseReleaseEvent\n");
                }
            }
            else
            {
                endPoint = event->globalPos();
                endPoint = ui->imgLabel->mapFromGlobal(endPoint);
                controller.removeGraph();
                controller.addGraph(startPoint,endPoint,color,ui->lineSizeSlider->value());
            }
            update();
        }
        else if(mCmd == mouseTranslate)
        {
            endPoint = event->globalPos();
            endPoint = ui->imgLabel->mapFromGlobal(endPoint);
            int x = endPoint.x();
            int y = endPoint.y();
             int len = controller.graphs.size();
            for(int i = 0; i < len; i++)
            {
                if(controller.graphs[i]->beChosen == true)
                {
                    int lastX = controller.graphs[i]->lastX;
                    int lastY = controller.graphs[i]->lastY;
                    Transformation::translate(controller.graphs[i],x-lastX,y-lastY);
                    controller.graphs[i]->lastX = x;
                    controller.graphs[i]->lastY = y;
                    controller.graphs[i]->beChosen = false;
                }
            }
        }
        else if(mCmd == mouseRotateIng)
        {
            int len = controller.graphs.size();
            for(int i = 0; i < len; i++)
            {
                controller.graphs[i]->beChosen = false;
            }
        }
        else if(mCmd == mouseRotateBegin)
        {
            mCmd = mouseRotateIng;
        }
        else if(mCmd == mouseScaleIng)
        {
            int len = controller.graphs.size();
            for(int i = 0; i < len; i++)
            {
                controller.graphs[i]->beChosen = false;
            }
        }
        else if(mCmd == mouseScaleBegin)
        {
            mCmd = mouseScaleIng;
        }
        else if(mCmd == mouseClip)
        {
            endPoint = event->globalPos();
            endPoint = ui->imgLabel->mapFromGlobal(endPoint);
            controller.graphs.pop_back();
            if(ui->clip1->checkState() == Qt::Checked)
                controller.clipAlgorithm = 0;
            else if(ui->clip2->checkState() == Qt::Checked)
                controller.clipAlgorithm = 1;
            else
                controller.clipAlgorithm = 1;
            int size = controller.graphs.size();
            for(int i = 0; i< size; i++)
            {
                if(controller.graphs[i]->shape == shapeLine)
                {
                    if(controller.clipAlgorithm == 0)
                        Transformation::clipCohenSutherland(startPoint,endPoint, (Line*)controller.graphs[i]);
                    else
                        Transformation::clipLiangBarsky(startPoint,endPoint,(Line*)controller.graphs[i]);
                }
            }
        }
    }
}

//对应主界面鼠标操作的按钮
void MainWindow::on_cmdLineButton_clicked()
{
    mCmd = mouseDraw;
    controller.cmd = cmdDrawLine;
}
void MainWindow::on_cmdCircleButton_clicked()
{
    mCmd = mouseDraw;
    controller.cmd = cmdDrawCircle;
}
void MainWindow::on_cmdEllipseButton_clicked()
{
    mCmd = mouseDraw;
    controller.cmd = cmdDrawEllipse;
}
void MainWindow::on_cmdPolygonButton_clicked()
{
    mCmd = mouseDraw;
    controller.cmd = cmdDrawPolygonStart;
}

void MainWindow::on_dyeButton_clicked()
{
    mCmd = mouseDye;
    controller.cmd = cmdFree;
}
//有关图形变换的操作
void MainWindow::on_cmdTranslateButton_clicked()
{
    mCmd = mouseTranslate;
    controller.cmd = cmdFree;
}
void MainWindow::on_cmdRotateButton_clicked()
{
    mCmd = mouseRotateBegin;
    controller.cmd = cmdFree;
}
void MainWindow::on_cmdScaleButton_clicked()
{
    mCmd = mouseScaleBegin;
    controller.cmd = cmdFree;
}
void MainWindow::on_cmdClipButton_clicked()
{
    mCmd = mouseClip;
    controller.cmd = cmdFree;
}


void MainWindow::on_saveButton_clicked()//保存画布
{
    QImage img = canvas->toImage();
    QString fileName = QFileDialog::getSaveFileName(this,
                                                    tr("保存画布"),
                                                    "",
                                                    tr("*.bmp;; *.png;; *.jpg;; *.tif;; *.GIF"));
    if(fileName.isEmpty() == false)
    {
        if(img.save(fileName) == true)
        {
            ui->statusBar->showMessage("画布保存成功");
        }
        else
        {
            QMessageBox::information(this,
                                     tr("保存画布失败"),
                                     tr("保存画布失败"));
        }
    }
}

void MainWindow::on_undoButton_clicked()
{
    if(controller.graphs.isEmpty()==false)
        controller.graphs.pop_back();
    update();
}

void MainWindow::on_openButton_clicked()
{
    path = QFileDialog::getOpenFileName(this, tr("选择图像"), ".", tr("Image Files(*.bmp *.png)"));
    if(! ( canvas->load(path) ) ) //加载图像
    {
        QMessageBox::information(this,
                                 tr("打开图像失败"),
                                 tr("打开图像失败!"));
    }
    else
    {
        QMessageBox::information(this,
                                 tr("打开图像成功"),
                                 tr("打开图像成功!"));
     }
}
