#include "graphUnit/graphUnit.h"

graphUnit::graphUnit()
{
    beChosen = false;
    shape = unKnown;
    id = -1;
    lineSize = 1;
    beDyed = false;
}

Shape graphUnit::getShape()
{
    return shape;
}
