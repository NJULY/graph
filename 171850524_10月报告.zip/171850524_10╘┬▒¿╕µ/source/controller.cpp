#include "controller.h"


Controller::Controller()
{
    unit = nullptr;
    cmd = cmdFree;
}

void Controller::addGraph(QPoint startPoint, QPoint endPoint, QColor color)
{
    if(cmd == cmdDrawLine)//画直线，鼠标开始和结束分别对应着直线端点
    {
        int x1, y1, x2, y2;
        x1 = startPoint.x();
        y1 = startPoint.y();
        x2 = endPoint.x();
        y2 = endPoint.y();
        //printf("%d-%d-%d-%d ",x1,y1,x2,y2);
        unit = new Line(x1, y1, x2, y2, color);
        graphs.push_back(unit);
    }
    else if(cmd == cmdDrawCircle)//画圆，鼠标点击为圆心，移动中计算半径
    {
        int x, y, r;
        int rX, rY;
        x = startPoint.x();
        y = startPoint.y();
        rX = endPoint.x();
        rY = endPoint.y();
        r = (int)sqrt(abs(rX - x)*abs(rX - x)+abs(rY - y)*abs(rY - y));
        unit = new Circle(x, y, r, color);
        graphs.push_back(unit);
    }
    else if(cmd == cmdDrawEllipse)//画椭圆，鼠标起点为椭圆中心，终点与起点可计算两个轴
    {
        int x, y, rx, ry;
        int sx, sy, ex, ey;
        sx = startPoint.x();
        sy = startPoint.y();
        ex = endPoint.x();
        ey = endPoint.y();
        x = sx;
        y = sy;
        rx = abs(sx-ex);
        ry = abs(sy-ey);
        unit = new Ellipse(x, y, rx, ry, color);
        graphs.push_back(unit);
    }
    else if(cmd == cmdDrawPolygonStart){
        int x1, y1, x2, y2;
        x1 = startPoint.x();
        y1 = startPoint.y();
        x2 = endPoint.x();
        y2 = endPoint.y();
        Line* line = new Line(x1, y1, x2, y2, color);
        Polygon* polygon = new Polygon(color);
        polygon->pushLine(*line);
        unit = polygon;
        graphs.push_back(unit);
    }
    else if(cmd == cmdDrawPolygonIng)
    {
        int x1, y1, x2, y2;
        x1 = startPoint.x();
        y1 = startPoint.y();
        x2 = endPoint.x();
        y2 = endPoint.y();
        Line* line = new Line(x1, y1, x2, y2, color);
        int size = graphs.size();
        if(graphs[size-1]->getShape() == shapePolygon)
        {
            Polygon* polygon = (Polygon*)graphs[size-1];
            polygon->pushLine(*line);
        }
        else
        {
            printf("栈顶元素非多边形!\n");
        }
    }
}

void Controller::removeGraph()
{
    if(graphs.isEmpty() == false)
    {
        if(cmd == cmdDrawPolygonIng)
        {
            int size = graphs.size();
            if(graphs[size-1]->getShape() == shapePolygon)
            {
                Polygon* polygon = (Polygon*)graphs[size-1];
                polygon->popLine();
            }
            else
            {
                printf("栈顶元素非多边形!\n");
            }
        }
        else
        {
            graphs.pop_back();
        }
    }
}

void Controller::reset()
{
    graphs.clear();
}

void Controller::paint(QPixmap* canvas)
{
    QVector<graphUnit*>::iterator i;
    for(i = graphs.begin(); i != graphs.end(); i++)
    {
        unit = *i;
        if(unit->getShape() == shapeLine)
        {
            Line* line = (Line*)unit;
            if(line != nullptr)
            {
                line->Bresenham_paint(canvas);
                line->DDA_paint(canvas);
            }
        }
        else if(unit->getShape() == shapeCircle)
        {
            Circle* circle = (Circle*)unit;
            if(circle != nullptr)
            {
                circle->paint(canvas);
            }
        }
        else if(unit->getShape() == shapeEllipse)
        {
            Ellipse* ellipse = (Ellipse*)unit;
            if(ellipse != nullptr)
            {
                ellipse->paint(canvas);
            }
        }
        else if(unit->getShape() == shapePolygon)
        {
            Polygon* polygon = (Polygon*)unit;
            if(polygon != nullptr)
            {
                polygon->paint(canvas);
            }
        }
    }
}
