#ifndef GRAPHUNIT_H
#define GRAPHUNIT_H
#include <QPixmap>
#include <QPainter>
#include <QColor>
#include <cmath>
#include <QVector>
enum Shape {unKnown, shapeLine, shapeCircle, shapeEllipse, shapePolygon};

class graphUnit
{
public:
    graphUnit();
    Shape getShape();
protected:
    bool beChosen;
    Shape shape;
    int id;
};

#endif
