#ifndef ELLIPSE_H
#define ELLIPSE_H

#include "graphUnit.h"

class Ellipse : public graphUnit
{
public:
    Ellipse();
    Ellipse(int x, int y, int rx, int ry, QColor color);
    void paint(QPixmap *canvas);

private:
    int x;
    int y;
    int rx;
    int ry;
    QColor color;
};

#endif // ELLIPSE_H
