#ifndef LINEDIALOG_H
#define LINEDIALOG_H

#include <QDialog>
#include <QColorDialog>
#include <QString>

namespace Ui {
class lineDialog;
}

class lineDialog : public QDialog
{
    Q_OBJECT

public:
    explicit lineDialog(QWidget *parent = nullptr);
    ~lineDialog();
    void getVal(int& x1, int& y1, int& x2, int& y2, QColor& color);

private slots:
    void on_okButton_clicked();

    void on_cancleButton_clicked();

    void on_colorButton_clicked();

private:
    Ui::lineDialog *ui;
    int x1,x2,y1,y2;
    QColor color;
};

#endif // LINEDIALOG_H
