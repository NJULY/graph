#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <QPoint>
#include <QColor>
#include <QVector>
#include <QPixmap>
#include "graphUnit/graphUnit.h"
#include "graphUnit/line.h"
#include "graphUnit/circle.h"
#include "graphUnit/ellipse.h"
#include "graphUnit/polygon.h"

#define CANVAS_W 600
#define CANVAS_H 600

enum Command {cmdFree, cmdDrawLine, cmdDrawCircle, cmdDrawEllipse,
              cmdDrawPolygonStart, cmdDrawPolygonIng
             };

class Controller
{
public:
    Controller();
    void addGraph(QPoint startPoint, QPoint endPoint, QColor color);
    void removeGraph();
    void reset();
    void paint(QPixmap* canvas);
    Command cmd;
    QVector<graphUnit*> graphs;//存储所有的图元
    graphUnit* unit;
};

#endif // CONTROLLER_H
